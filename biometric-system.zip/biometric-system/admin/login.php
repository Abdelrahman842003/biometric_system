<?php
// Redirect to the main login page
header('Location: ../login.php');
exit();
?>
